function login()
{
var name=document.getElementById('uname').value
var password=document.getElementById('upass').value
var checkname=/^[A-za-z0-9.]{3,}@[A-Za-z]{3,}[.]{1}[A-Za-z.]{2,6}$/;
var checknumber=/^[789][0-9]{9}$/;
var checkpassword=/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-z0-9!@#$%^&*]{8,16}$/;
if(checkname.test(name))
{
 if(checkpassword.test(password))
 {
  
 }
 else
{
document.getElementById('demo1').innerHTML="Enter Valid password"
return false
}
}
else if(checknumber.test(name))
{
if(checkpassword.test(password))
 {
  
 }
 else
{
document.getElementById('demo1').innerHTML="Enter Valid password"
return false
}
}
else
{
document.getElementById('demo').innerHTML="invalid username or mobile number"
return false
}
}