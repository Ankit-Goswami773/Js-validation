
function checkname()
{
var fname=document.getElementById('fname').value
var firstname=/^[A-Za-z]{3,15}$/;
if(firstname.test(fname))
{
document.getElementById('uname').innerHTML=" "
 return true
}
else
{
document.getElementById('uname').innerHTML="Invalid name"
 return false
}
}

function checklname()
{
var lname=document.getElementById('lname').value
var lastname=/^[A-Za-z]{3,15}$/;
if(lastname.test(lname))
{
document.getElementById('ulname').innerHTML=" "
return true
}
else
{
document.getElementById('ulname').innerHTML="Invalid a lastname"
return false
}
}

function checkemail()
{
var email=document.getElementById('email').value
var emailcheck=/^[A-za-z0-9.]{3,}@[A-Za-z]{3,}[.]{1}[A-Za-z.]{2,6}$/;
if(emailcheck.test(email))
{
document.getElementById('emailer').innerHTML=" "
return true
}
else
{
document.getElementById('emailer').innerHTML="not a email"
return false
}
}

function checkmobile()
{
var number=document.getElementById('number').value
var mobilecheck=/^[789][0-9]{9}$/;	
if(mobilecheck.test(number))
{
document.getElementById('mnumber').innerHTML=" "
return true
}
else
{
document.getElementById('mnumber').innerHTML="Invalid number"
return false
}	
}

function checkpassw()
{
var password=document.getElementById('password').value
var passwordcheck=/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-z0-9!@#$%^&*]{8,16}$/;
if(passwordcheck.test(password))
{
document.getElementById('upass').innerHTML=" "
return true
}
else
{
document.getElementById('upass').innerHTML="password atleast one special symbol one number one alpha"
return false
}		
}	
function checkcpassw()
{
var password=document.getElementById('password').value
var cpassword=document.getElementById('cpassword').value
if(password.match(cpassword))
{
document.getElementById('cpass').innerHTML=" "
return true
}
else
{
document.getElementById('cpass').innerHTML="password does'nt match"
return false
}		
}

function checkdob()	
{
var date=document.getElementById('birthday').value
var datecheck=/^([0-9]{2})-([0-9]{2})-([0-9]{4})$/;
if(datecheck.test(date))
{
var parts = date.split("-");
var dtDOB = new Date(parts[1] + "/" + parts[0] + "/" + parts[2]);
var dtCurrent = new Date();
if (dtCurrent.getFullYear() - dtDOB.getFullYear() < 18)
 {
 document.getElementById('berr').innerHTML="Invalid age"
 return false
            }
			else
			{
			return true
             }
}
else
{
document.getElementById('berr').innerHTML="Incoreect dob format"
return false
}	
}
function checkadd()
{
var address=document.getElementById('address').value
var addresscheck=/^[0-9, A-z]{3,30}$/;	
if(addresscheck.test(address))
{
document.getElementById('uadd').innerHTML=" "
return true
}
else
{
document.getElementById('uadd').innerHTML="Invalid Address"
return false
}			
}
function checkcity()
{
var city=document.getElementById('city').value
var citycheck=/^[A-Za-z]{3,20}$/;
if(citycheck.test(city))
{
document.getElementById('ucity').innerHTML=" "
return true
}
else
{
document.getElementById('ucity').innerHTML="Invalid city"
return false
} 	
}
function checkstate()
{
var state=document.getElementById('state').value
var statecheck=/^[A-Z, a-z]{3,20}$/;
if(statecheck.test(state))
{
document.getElementById('ustate').innerHTML=" "
return true
}
else
{
document.getElementById('ustate').innerHTML="Invalid State"
return false
} 	
}
function checkcountry()
{
var country=document.getElementById('country').value
var countrycheck=/^[A-Za-z]{2,20}$/;	
if(countrycheck.test(country))
{
document.getElementById('ucountry').innerHTML=" "
return true
}
else
{
document.getElementById('ucountry').innerHTML="Invalid country"
return false
}
}
function checkpin()
{
var pin=document.getElementById('pincode').value
var pincode=/[0-9]/;
if(pincheck.test(pin))
{
document.getElementById('upin').innerHTML=" "
return true
}
else
{
document.getElementById('upin').innerHTML="Invalid pin code"
return false
}
}

function validate()
{ 
 var name=checkname();
   if(name==true)
   {   
   }
else
{
	document.getElementById('uname').innerHTML="Invalid name"
	return false
}
 var lastname=checklname();
 if(lastname==true)
   {   
   }
else
{
	document.getElementById('ulname').innerHTML="Invalid last name"
	return false
}
var email=checkemail();
if(email==true)
   {   
   }
else
{
	document.getElementById('emailer').innerHTML="Invalid email"
	return false
}
var number=checkmobile();
if(email==true)
   {   
   }
else
{
	document.getElementById('mnumber').innerHTML="Invalid mobile no."
	return false
}
var pass=checkpassw();
if(pass==true)
{}
	else
	{
		document.getElementById('upass').innerHTML="password atleast one special symbol one number one alpha"
return false
	}
	var cpass=checkcpassw();
	if(cpass==true)
	{}
else
{
document.getElementById('cpass').innerHTML="password does'nt match"
return false	
}
var dob=checkdob();
if(dob==true)
{
document.getElementById('berr').innerHTML=""	
}
else
{
document.getElementById('berr').innerHTML="Incoreect dob format"
return false	
}
var address=checkadd();
if(address==true)
{	
}
else
{
document.getElementById('uadd').innerHTML="Invalid Address"
return false
}
var city=checkcity();
	if(city==true)
	{
}
else
{
document.getElementById('ucity').innerHTML="Invalid City"
return false
}
var state=checkstate();
if(state==true)
{}
else
{
document.getElementById('ustate').innerHTML="Invalid State"
return false	
}
var country=checkcountry();
if(country==true)
{}
else
{
document.getElementById('ucountry').innerHTML="Invalid country"
return false
}
var pin=checkpin()
if(pin==true)
{}
else
{
document.getElementById('upin').innerHTML="Invalid pin code"
return false	
}

}
